const dishes = [
    {
      id: 1,
      type: 'Sisig',
      province: 'Pampanga',
      price: 220,
      size: 'small'
    },
    {
      id: 2,
      type: 'Salpicao',
      province: 'Quezon',
      price: 180,
      size: 'medium'
    },
    {
      id: 3,
      type: 'Bagnet',
      province: 'Ilocos',
      price: 370,
      size: 'small'
    },
  ];

module.exports = dishes;