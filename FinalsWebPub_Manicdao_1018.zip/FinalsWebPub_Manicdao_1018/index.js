const bodyParser = require('body-parser');
const express = require('express');
const app = express();
const data = require('./data');
app.use(express.static('public'));

var urlencodedParser = bodyParser.urlencoded({ extended: false });


app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public' + '/home.html');
});

app.get('/dishes', (req, res) => {
  res.send(data);
});

app.get('/dishes/:type', (req, res) => {
  const dishType = req.params.type;
  const dish = dishes.find((dish) => dish.type === dishType);
  if (dish) {
    res.json(dish);
  } else {
    res.status(404).send('Record not found.');
  }
});

app.get('/dishes/id/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const dish = data.find((d) => d.id === id);
  if (dish) {
    res.json(dish);
  } else {
    res.status(404).send('Record not found.');
  }
});

app.listen(3050, function () {
  console.log('Server is Up');
});
