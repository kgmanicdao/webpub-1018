function loadDishes()
{
    fetch('/dishes')
    .then(response => response.json())
    .then(dishes => {
        const tableBody = document.querySelector("tbody")
        dishes.forEach(dish => {
            const row = 
            `<tr>
                <td>${dish.id}</td>
                <td>${dish.type}</td>
                <td>${dish.province}</td>
                <td>${dish.price}</td>
                <td>${dish.size}</td>
            </tr>
            `
        tableBody.innerHTML += row;
        })
    })
    .catch(error => console.log('Error fetching dishes.', error));
}

function loadDish(dishID)
{
    fetch(`/dishes/id/${dishID}`)
    .then(response => response.json())
    .then(dish => {
        const tableBody = document.querySelector("tbody");
            const row = 
            `<tr>
                <td>${dish.id}</td>
                <td>${dish.type}</td>
                <td>${dish.province}</td>
                <td>${dish.price}</td>
                <td>${dish.size}</td>
            </tr>
            `
        tableBody.innerHTML += row;
        })
    .catch(error => console.log('Error fetching dishes.', error));
}